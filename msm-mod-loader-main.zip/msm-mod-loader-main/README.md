# My Singing Monsters Mod Manager
### What does it do?
It allows you to easily turn on/off any mods you have installed with just single click and contains tools that help with modding.
### Join our Discord Server!
https://discord.gg/pNtCG7PeuF
