module.exports = {
    'toml': require('./toml'),
    'sprite': require('./sprite'),
    'logger': require('./logger').logger,
    'manager': require('./manager'),
    'lua': require('./lua')
}